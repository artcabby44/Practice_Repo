Instruction

-Download zip
-Extract
-Open the folder and click the'Click-to-run.bat'



Disclaimer:

I do not own the Debloaters script.

Debloater script by Chris Titus 
website - https://christitus.com/debloat-windows-10/ 
github repo - https://github.com/ChrisTitusTech/win10script

Debloater script by Sycnex
github repo - https://github.com/Sycnex/Windows10Debloater

